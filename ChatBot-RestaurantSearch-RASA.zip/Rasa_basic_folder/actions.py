from __future__ import absolute_import
from __future__ import division
from __future__ import unicode_literals

from rasa_sdk import Action, Tracker
from rasa_sdk.events import AllSlotsReset, SlotSet, Restarted
import zomatopy
import json
import requests
from concurrent.futures import ThreadPoolExecutor
import smtplib
from email.message import EmailMessage
import re
from Constants import BASE_URL, HEADERS, API_KEY, TIER1, TIER2, FROM_ADDR, LOGIN, PASS, SMTP_PORT, SMTP_HOST
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

email_rest = []


# Location class to identify the tier1 and tie2 cities
class Location():
    def __init__(self):
        self.tier_cities = {
            "tier1": TIER1,
            "tier2": TIER2
        }

    # Validate the location which entered by the user , whether the location exist in tier1 and tier2 cities
    def validate_location(self, loc):
        # If no location provided then it will return false
        if loc is None:
            return False
        return loc.lower() in self.tier_cities['tier1'] or loc.lower() in self.tier_cities['tier2']


class ActionSearchRestaurants(Action):

    def name(self):
        return 'action_search_restaurants'

    def run(self, dispatcher, tracker, domain):
        config = {"user_key": API_KEY}
        # using zomato module connect to zomato api and pull the information
        zomato = zomatopy.initialize_app(config)

        # Get the location from location slot
        loc = tracker.get_slot('location')

        # Get the location from cuisine slot
        cuisine = tracker.get_slot('cuisine')
        # set the cusine dict with cusine code to search the cuisine
        cuisine_dict = {'american': 1, 'chinese': 25, 'italian': 55,
                        'mexican': 73, 'north indian': 50, 'south indian': 85}


        # Get the location from pricemin and pricemax slot
        pricemin = int(tracker.get_slot('pricemin'))
        pricemax = int(tracker.get_slot('pricemax'))

        # pull location information from the zomato api
        location_detail = zomato.get_location(loc, 1)

        # convert the location detail to json format using json dumps
        data = json.loads(location_detail)
        if len(data['location_suggestions']) == 0:
            dispatcher.utter_message(
                "We do not operate in " + str(loc) + " yet. Please try some other city.")
            return [SlotSet('location', 'None'), SlotSet('check_op', False)]
        lat = data["location_suggestions"][0]["latitude"]
        lon = data["location_suggestions"][0]["longitude"]

        # pull the restaurant information from zomato api
        results = zomato.restaurant_search("", lat, lon, str(cuisine_dict.get(cuisine)), 20)

        # load the json data from the pulled result.
        restaurants = json.loads(results)
        # intialiaze the response variable with null string
        response = ""

        # Cheking if zomato api returns data
        if restaurants['results_found'] == 0:
            response = "no results"
        else:

            # creating object from the location class
            chk_loc = Location()

            # validating location based on the location information
            if chk_loc.validate_location(loc) is False:
                # if location is not available then it will throw below message to user
                dispatcher.utter_message(
                    "We do not operate in " + str(loc) + " yet. Please try some other city.")
                # now it set slot and return information and exit this funtion
                return [SlotSet('location', 'None'), SlotSet('check_op', False)]

            rest_list = []

            for res in restaurants['restaurants']:

                if int(pricemin) <= int(res['restaurant']['average_cost_for_two']) <= int(pricemax):
                    rest_list.append(res)

            # List is reverse sorted based on the rating.
            rest_list_sorted_price = sorted(rest_list,
                                      key=lambda x: float(x['restaurant']['average_cost_for_two']),
                                      reverse=True)

            # List is reverse sorted based on the rating.
            rest_list_sorted = sorted(rest_list_sorted_price,
                                      key=lambda x: float(x['restaurant']['user_rating']['aggregate_rating']),
                                      reverse=True)

            # Now build the response for email and commandline display
            response_disp = ""
            restaurant_exist = False

            # If list size is zero which means no results we got from the list then this will return
            if len(rest_list_sorted) == 0:
                dispatcher.utter_message("Sorry, no results found :(" + "\n")
            else:

                # Now get the first 5 records from the sorted list
                rest_list_sorted5 = rest_list_sorted[:5]

                # Now get the first 10 records from the sorted list
                rest_list_sorted10 = rest_list_sorted[:10]

                # setting global variable
                global email_rest

                # setting list
                email_rest = rest_list_sorted10
                if (email_rest and len(email_rest) > 0):
                    restaurant_exist = True

                # building the response message to return
                for restaurant in rest_list_sorted5:
                    response_disp = response_disp + restaurant['restaurant']['name'] + " in " + \
                                    restaurant['restaurant']['location']['address'] + " which has been rated " + \
                                    restaurant['restaurant']['user_rating']['aggregate_rating'] + "\n"

        # Now message will displayed to user
        dispatcher.utter_message(response_disp)

        # now set location and resturan_exist slot with values and return
        return [SlotSet('location', loc), SlotSet('restaurant_exist', restaurant_exist)]


# Checking location is available or not
class CheckLocation(Action):

    def name(self):
        return 'check_location'

    def run(self, dispatcher, tracker, domain):

        # pull location from location slot
        loc = tracker.get_slot('location')

        # creating object from the location class
        chk_loc = Location()

        # validating location based on the location information
        if chk_loc.validate_location(loc) and loc is not None:

            # set the slot if the location exist
            return [SlotSet('location', loc), SlotSet('check_op', True)]
        else:

            # if the location not exist it will throw message and return
            dispatcher.utter_message(
                "We do not operate in " + str(loc) + " yet. Please try some other city.")
            return [SlotSet('location', 'None'), SlotSet('check_op', False)]


# checking whether the cost exist or not
class Cost(Action):
    def name(self):
        return 'check_cost'

    def run(self, dispatcher, tracker, domain):

        pricemin = None
        pricemax = None
        price_lookup = {
            "min": [0, 300, 700],
            "max": [300, 700, 10000]
        }
        error_msg = "I'm sorry!! given price range is not available, please re-enter."
        # putting in try block for better error handling
        try:
            # pulling the minimum and maximum price from the slot.
            pricemin = tracker.get_slot('pricemin')
            pricemax = tracker.get_slot('pricemax')

        except ValueError:
            # return the error message to user
            dispatcher.utter_message(error_msg)
            return [SlotSet('pricemin', None), SlotSet('pricemax', None), SlotSet('check_op', False)]

        # check whether the price falls between the ranges
        if int(pricemin) >= 0 and int(pricemax) <= 300  and not int(pricemin) >= 300 :
            # return minimum and maximum price if exist
            return [SlotSet('pricemin', 0), SlotSet('pricemax', 300), SlotSet('check_op', True)]
        elif int(pricemin) >= 300 and int(pricemax) <= 700 and not int(pricemin) >= 700:
            # return minimum and maximum price if exist
            return [SlotSet('pricemin', 300), SlotSet('pricemax', 700), SlotSet('check_op', True)]

        elif int(pricemin) >= 700 and int(pricemax) < 10000:
        # return minimum and maximum price if exist
            return [SlotSet('pricemin', 700), SlotSet('pricemax', 10000), SlotSet('check_op', True)]
        else:
            # If not this will return to re-enter the price
            dispatcher.utter_message(error_msg)
            return [SlotSet('pricemin', 0), SlotSet('pricemax', 0), SlotSet('check_op', False)]


# validate Cuisine
class Cuisine(Action):

    def name(self):
        return 'verify_cuisine'

    def run(self, dispatcher, tracker, domain):

        cuisines = ['chinese', 'mexican', 'italian', 'american', 'south indian', 'north indian']
        error_msg = "Sorry!! The cuisine is not supported. Please re-enter."

        # getting the cuisine from cuisine slot
        cuisine = tracker.get_slot('cuisine')

        try:
            # converting the pulled value to lowecase for better handling
            cuisine = cuisine.lower()
        except (RuntimeError, TypeError, NameError, AttributeError):
            # if there is some error then it will throw the error message
            dispatcher.utter_message(error_msg)
            return [SlotSet('cuisine', None), SlotSet('check_op', False)]

        # looking for the cuisine exist in cuisines list and  return respective values
        if cuisine in cuisines:
            return [SlotSet('cuisine', cuisine), SlotSet('check_op', True)]
        else:
            dispatcher.utter_message(error_msg)
            return [SlotSet('cuisine', None), SlotSet('check_op', False)]


# Configure and make things work on send mail
class SendMail(Action):

    def __init__(self):
        pass

    def name(self):
        return 'send_email'

    def run(self, dispatcher, tracker, domain):

        # Open SMTP connection to our email id.
        s = smtplib.SMTP_SSL(host=SMTP_HOST, port=SMTP_PORT)
        s.login(LOGIN, PASS)

        # Create the msg object
        msg = EmailMessage()

        # get the emailid from emailid slot which entered by the user
        email = str(tracker.get_slot('emailid'))

        # validating the email address, this will segregate emailid, whether it got from slack or commandline
        if re.search("\|", email):
            email = str(tracker.get_slot('emailid')).split("|")[1]
        else:
            email = str(tracker.get_slot('emailid'))

        # Get location and cuisines to put in the email
        loc = tracker.get_slot('location')
        cuisine = tracker.get_slot('cuisine')
        global email_rest
        # get the resturant count from the list
        email_rest_count = len(email_rest)

        # Framing the subject from the content
        subj = "Top " + str(email_rest_count) + " " + cuisine.capitalize() + " restaurants in " + str(
            loc).capitalize()

        # Framing message from the subject
        mesg = "<html><body> Hi there! <br /><br />Here are the " + subj + "." + "<br />" + "<br />" + \
               "<br /><table><tr><th></th><th>Restaurant Name</th><th>Restaurant Address</th><th>Average Price for 2 people</th><th>User Rating</th></tr>"

        # iterating and framing messgae
        for restaurant in email_rest:
            mesg = mesg + "<tr><td style=\"word-wrap: break-word;text-align: center;\"><img src=\"" + \
                   restaurant['restaurant'][
                       'thumb'] + "\"></td><td style=\"word-wrap: break-word;text-align: center;\">" + \
                   restaurant['restaurant']['name'] + "</td><td style=\"word-wrap: break-word;text-align: center;\"> " + \
                   restaurant['restaurant']['location'][
                       'address'] + "</td><td style=\"word-wrap: break-word;text-align: center;\"> Rs." + \
                   str(restaurant['restaurant'][
                           'average_cost_for_two']) + "</td><td style=\"word-wrap: break-word;text-align: center;\"> " + \
                   str(restaurant['restaurant']['user_rating']['aggregate_rating']) + "<br /><br /></td><tr>"

        mesg = mesg + '</table></body></html>'
        # Setting subject and from address
        msg['Subject'] = subj
        msg['From'] = FROM_ADDR

        # Setting the content and to email address
        msg.set_content(mesg)
        msg.add_alternative(mesg, subtype='html')
        msg['To'] = str(email)

        # sending message to respective email address
        s.send_message(msg)

        # need to exit the smtp after sending message
        s.quit()

        dispatcher.utter_message("<===> Enjoy your food :-) <===>")

        return []
