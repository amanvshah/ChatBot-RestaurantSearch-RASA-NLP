## intent:greet
- hey
- howdy
- hey there
- Hello
- hello
- Hello!
- hi
- good morning
- good evening
- dear sir
- hi how are you

## intent:affirm
- yes
- yep
- yeah
- indeed
- that's right
- ok
- great
- right, thank you
- correct
- great choice
- sounds really good
- Yes

## intent:deny
- No, thanks
- Never mind
- Don't bother
- Nope
- no
- No
- nope

## intent:restaurant_search
- i'm looking for a place to eat
- I want to grab lunch
- I am searching for a dinner spot
- i'm looking for a place in [Bangalore](location)
- show me [chinese](cuisine) restaurants
- show me [chines]{"entity": "cuisine", "value": "chinese"} restaurants in [chennai](location)
- find me a [mexican](cuisine) place in [Hyderabad](location)
- search for restaurants
- anywhere in [Ahmedabad](location)
- I am looking for [South indian](cuisine) food
- I am looking a restaurant in [Nashik](location)
- in [Cuttack](location)
- [South Indian](cuisine)
- [North Indian](cuisine)
- [Italian](cuisine)
- [American](cuisine)
- [Chinese]{"entity": "cuisine", "value": "chinese"}
- [chinese](cuisine)
- [chines]{"entity": "cuisine", "value": "chinese"}
- [mexican](cuisine)
- in [delhi](location)
- In [Delhi](location)
- In [Delhi](location).
- I am looking for some restaurants in [hyderbad](location)
- I am looking for some restaurants in [delhi](location)
- I am looking for [mexican](cuisine) fusion food
- [south indian](cuisine) restaurant
- please help me to find restaurants in [pune](location)
- less than [113](pricemax)
- More than [113](pricemin)
- i'm looking for a place in [Delhi](location) under [546](pricemax)
- i'm looking for a place in [Delhi](location) over [556](pricemin)
- i'm looking for a place in [Delhi](location) within [687](pricemax)
- i'm looking for a place in [Delhi](location) between [620](pricemin) and [1244](pricemax)
- i'm looking for a place in [Delhi](location) between [527](pricemin)-[872](pricemax)
- i'm looking for a place in [Bangalore](location) under [556](pricemax)
- i'm looking for a place in [Bangalore](location) over [565](pricemin)
- i'm looking for a place in [Bangalore](location) within [678](pricemax)
- i'm looking for a place in [Bangalore](location) between [634](pricemin) and [1133](pricemax)
- i'm looking for a place in [Bangalore](location) between [527](pricemin)-[872](pricemax)
- i'm looking for a place in [Lucknow](location) under [556](pricemax)
- i'm looking for a place in [Lucknow](location) over [565](pricemin)
- i'm looking for a place in [Lucknow](location) within [678](pricemax)
- i'm looking for a place in [Lucknow](location) between [634](pricemin) and [1133](pricemax)
- i'm looking for a place in [Lucknow](location) between [527](pricemin)-[872](pricemax)
- show me [chinese](cuisine) restaurants over [6243](pricemin)
- show me [chines]{"entity": "cuisine", "value": "chinese"} restaurants in [chennai](location) within [638](pricemax)
- I am looking for [South indian](cuisine) food below [453](pricemax)
- I am looking a restaurant in [Nashik](location) from [391](pricemin) to [845](pricemax)
- less than [300](pricemax)
- More than [301](pricemin)
- [301](pricemin) to [700](pricemax)
- Rs [301](pricemin) to [700](pricemax)
- More than [1000](pricemin)
- [Ahmedabad](location)
- [Bangalore](location)
- [Chennai](location)
- [Delhi](location)
- [Hyderabad](location)
- [Kolkata](location)
- [Mumbai](location)
- [Pune](location)
- [Agra](location)
- [Ajmer](location)
- [Aligarh](location)
- [Allahabad](location)
- [Amravati](location)
- [Amritsar](location)
- [Asansol](location)
- [Aurangabad](location)
- [Bareilly](location)
- [Belgaum](location)
- [Bhavnagar](location)
- [Bhiwandi](location)
- [Bhopal](location)
- [Bhubaneswar](location)
- [Bikaner](location)
- [Bokaro Steel City](location)
- [Chandigarh](location)
- [Coimbatore](location)
- [Cuttack](location)
- [Dehradun](location)
- [Dhanbad](location)
- [Durg-Bhilai Nagar](location)
- [Durgapur](location)
- [Erode](location)
- [Faridabad](location)
- [Firozabad](location)
- [Ghaziabad](location)
- [Gorakhpur](location)
- [Gulbarga](location)
- [Guntur](location)
- [Gurgaon](location)
- [Guwahati](location)
- [Gwalior](location)
- [Hubli-Dharwad](location)
- [Indore](location)
- [Jabalpur](location)
- [Jaipur](location)
- [Jalandhar](location)
- [Jammu](location)
- [Jamnagar](location)
- [Jamshedpur](location)
- [Jhansi](location)
- [Jodhpur](location)
- [Kannur](location)
- [Kanpur](location)
- [Kakinada](location)
- [Kochi](location)
- [Kottayam](location)
- [Kolhapur](location)
- [Kollam](location)
- [Kota](location)
- [Kozhikode](location)
- [Kurnool](location)
- [Lucknow](location)
- [Ludhiana](location)
- [Madurai](location)
- [Malappuram](location)
- [Mathura](location)
- [Goa](location)
- [Mangalore](location)
- [Meerut](location)
- [Moradabad](location)
- [Mysore](location)
- [Nagpur](location)
- [Nanded](location)
- [Nashik](location)
- [Nellore](location)
- [Noida](location)
- [Palakkad](location)
- [Patna](location)
- [Pondicherry](location)
- [Raipur](location)
- [Rajkot](location)
- [Rajahmundry](location)
- [Ranchi](location)
- [Rourkela](location)
- [Salem](location)
- [Sangli](location)
- [Siliguri](location)
- [Solapur](location)
- [Srinagar](location)
- [Sultanpur](location)
- [Surat](location)
- [Thiruvananthapuram](location)
- [Thrissur](location)
- [Tiruchirappalli](location)
- [Tirunelveli](location)
- [Tiruppur](location)
- [Ujjain](location)
- [Bijapur](location)
- [Vadodara](location)
- [Varanasi](location)
- [Vasai-Virar City](location)
- [Vijayawada](location)
- [Visakhapatnam](location)
- [Warangal](location)
- less than [144](pricemax)
- less than [693](pricemax)
- less than [859](pricemax)
- less than [2344](pricemax)
- [442](pricemin) to [824](pricemax)
- Rs [223](pricemin) to [646](pricemax)
- More than [144](pricemin)
- More than [693](pricemin)
- More than [859](pricemin)
- More than [700](pricemin)
- Less than [144](pricemax)
- I'm hungry. Looking out for some good [chinese](cuisine) restaurants in [chandigarh](location).
- Looking out for some good [south indian](cuisine) restaurants in [chennai](location).
- Looking out for some good [mexican](cuisine) restaurants in [mumbai](location).
- I would love to have some [South Indian](cuisine) food in [Bangalore](location)
- can you quickly get me a restuarant
- please find a restuarant
- please find a resturant
- [Mexican]{"entity": "cuisine", "value": "mexican"}
- please find me a resturant in [chennai](location)
- find me a restuarant in [chennai](location)
- find me a restaurant in [ajmer](location)
- [300](pricemin) to [700](pricemax)
- find a restaurant
- [vadodara](location)
- greater than [700](pricemin)
- [italian](cuisine) restaurant in [chennai](location) above [700](pricemin)
- search [mexican](cuisine) restaurant in [pune](location)
- from [300](pricemin) to [700](pricemax)
- find restaurant in [akola](location)
- find me restaurant in [akola](location)
- [nashik](location)
- [north indian](cuisine)
- maximum [300](pricemax)
- [akola](location)
- find me restaurant in [mumbai](location)
- [Thai](location)
- [Thai](cuisine)
- [Greek](cuisine)
- restaurant in [gurgaon](location)
- [250](pricemin) to [550](pricemax)
- within [450](pricemin) and [800](pricemax)
- hello please find me restarurant
- [bharuch](location)
- [bhavnagar](location)
- search restaurant in [bharuch](location)
- find restaurant in [ajmer](location)
- [south indian](cuisine)
- between [400](pricemin) and [800](pricemax)

## intent:goodbye
- bye
- goodbye
- good bye
- stop
- end
- farewell
- Bye bye
- have a good one

## intent:send_mail
- my email id is [sesaravanan7@gmail.com](emailid)
- please send it to [sesaravanan7@gmail.com](emailid)
- my email id is [aman.v.shah@hotmail.com](emailid)
- please send it to [aman.v.shah@hotmail.com](emailid)
- [aman.v.shah@hotmail.com](emailid)
- [sesaravanan7@gmail.com](emailid)
- [aman.v.shah](emailid)

## synonym:Bangalore
- bengaluru
- bangalore
- Bangalur

## synonym:Bokaro Steel City
- Bokaro
- Bokaro Steel City

## synonym:Cuttack
- Cuttck
- Cuttak
- Cuttack

## synonym:Durg-Bhilai Nagar
- Durg Nagar
- Bhilai Nagar
- Durg-Bhilai

## synonym:Firozabad
- Firozbad
- Firzabad
- Firozabad

## synonym:Hubli-Dharwad
- Hubli
- Dharwad
- Hubli-Darwad

## synonym:Jaipur
- Jaipu

## synonym:Kannur
- Kanur
- Kannur

## synonym:Kochi
- Cochi
- cochin
- Kochi

## synonym:Kottayam
- Kotayam
- Kottyam
- Kottayam

## synonym:Lucknow
- talian

## synonym:Tiruchirappalli
- Tiruchirapalli
- Tiruchirappali
- Tiruchirapali

## synonym:Vasai-Virar City
- Vasai City
- Virar City
- Vasai-Virar City

## synonym:Visakhapatnam
- Visakapatnam
- Vishakhapatnam
- Vishakapatnam

## synonym:agra
- Agra

## synonym:ahmedabad
- Ahmedabad
- Ahmedbad
- Ahmeadbad

## synonym:ajmer
- Ajmer
- ajmr
- ajmer

## synonym:aligarh
- alligarh
- Aligarh
- Aligadh

## synonym:allahabad
- Allahbad
- Alahabad
- Illahabad
- Prayagraj

## synonym:american
- American
- americn
- amrican

## synonym:amravati
- Amrvati
- Amravatti
- Amaravati

## synonym:amritsar
- amratsar
- amaritsar
- amrtsar

## synonym:asansol
- asnsol
- asansole
- asansol

## synonym:aurangabad
- aurangabad
- arangbad
- aurangabd

## synonym:bareilly
- barelly
- bareilly

## synonym:belgaum
- Belgam
- Belegaum
- Belegam

## synonym:bhavnagar
- bhavanagar
- Bhavnagar
- bhaavnagar

## synonym:bhiwandi
- bhiwaandi
- biwandi
- bhiwandi

## synonym:bhopal
- Bhopa
- Bhopl
- Bhopal

## synonym:bhubaneswar
- bhubaneswar
- Bhuvaneswar
- Bhubaneshwar

## synonym:bijapur
- Bijpur
- Bijapur

## synonym:bikaner
- Bikaner

## synonym:chandigarh
- Chandigarh
- Chandigadh
- Chandigar

## synonym:chennai
- chenai
- chenni
- madras

## synonym:chinese
- chines
- Chinese
- Chines

## synonym:coimbatore
- Coimbatore
- cbe
- Coimbator

## synonym:dehradun
- Dehradun
- Deharadun

## synonym:delhi
- New Delhi
- Delli
- Dilli

## synonym:dhanbad
- Dhanabad
- Dhanbd
- Dhanbad

## synonym:durgapur
- Duragapur
- Durgapure
- Durgapur

## synonym:erode
- Erode

## synonym:faridabad
- Faridabd
- Fardabad
- Faridabad

## synonym:ghaziabad
- Gaziabad
- Ghazibad
- Ghaziabad

## synonym:gorakhpur
- Gorakpur
- Gorkhpur
- Gorakhpur

## synonym:gulbarga
- Gulbrga
- Gulbarg
- Gulbarga

## synonym:guntur
- Guntr
- Gantur
- Guntur

## synonym:gurgaon
- Gurugaon
- Gurugram
- Gurgao

## synonym:guwahati
- Gowahati
- Guwahathi
- Guwahati

## synonym:gwalior
- Gwaliar
- Ghwaliar
- Gwalior

## synonym:hyderabad
- Hyderabad
- hyderbad
- hyderabd

## synonym:indore
- Indor
- Indore

## synonym:italian
- Italian
- Italin
- Itlian

## synonym:jabalpur
- jabalpur
- Jablpur
- Jabalpur

## synonym:jaipur
- Jaipure
- Jaypur
- Jaipur

## synonym:jalandhar
- Jalandhr
- Jalanadhar
- Jalandar

## synonym:jammu
- Jammu

## synonym:jamnagar
- Jamanagar
- Jamnagr
- Jamnagar

## synonym:jamshedpur
- jamshedpure
- Jamshedpur

## synonym:jhansi
- Jansi
- Jhanasi
- Jhansi

## synonym:jodhpur
- Jodpur
- Jodhpure
- Jodhpur

## synonym:kakinada
- Kakinda
- Kakinad
- Kakinada

## synonym:kanpur
- cawnpur
- Kaanpur
- Kanpur

## synonym:kolhapur
- Kolapur
- Kohlapur
- Kolhapur

## synonym:kolkata
- Kolkata
- Calcutta
- Kolkatta

## synonym:kollam
- Kolam
- Kollam

## synonym:kota
- Kota

## synonym:kozhikode
- Kozhikod
- Kozhikode

## synonym:kurnool
- Kurnol
- Koornool
- Kurnool

## synonym:lucknow
- Lucknow
- Lko
- Luknow

## synonym:ludhiana
- Ludiana
- Ludhiana

## synonym:madurai
- Madurai

## synonym:malappuram
- Malapuram
- Mallappuram
- Malappuram

## synonym:mangalore
- Mangalor
- Manglore
- Mangalore

## synonym:mathura
- Matura
- Mathura

## synonym:meerut
- Merut
- Meerut

## synonym:mexican
- Mexican
- Mexicn
- mxican

## synonym:moradabad
- Muradabad
- Moradbad
- Moradabad

## synonym:mumbai
- Mumbai
- Bombai
- Bombay

## synonym:mysore
- mysore
- Mysor
- Mysure

## synonym:nagpur
- Nagpure
- Nagpor
- Nagpur

## synonym:nanded
- Nanded

## synonym:nashik
- Nasik
- Nashik

## synonym:nellore
- Nellor
- Nelore
- Nellore

## synonym:noida
- greater Noida
- G. Noida
- Noida

## synonym:north indian
- North Indian
- North indian
- north Indian

## synonym:palakkad
- Palakad
- Pallakkad
- Pallakad

## synonym:patna
- Patna

## synonym:pondicherry
- Puducherry
- Puducherri
- Pondi

## synonym:pune
- Pne
- Puna
- puna

## synonym:raipur
- Raipur

## synonym:rajahmundry
- Rajamundry
- Rajhmundry
- Rajmundry

## synonym:rajkot
- Rjakot
- Raajkot
- Rajkot

## synonym:ranchi
- Rancih
- Ranchi

## synonym:rourkela
- Rourkel
- Rorkela
- Rourekla

## synonym:salem
- Selam
- Selem
- Salem

## synonym:sangli
- sangli
- Sangil
- Sangli

## synonym:siliguri
- Siligur
- Siligudi
- Silguri

## synonym:solapur
- Sholapur
- Solpur
- Solapur

## synonym:south indian
- South Indian
- South indian
- south Indian

## synonym:srinagar
- Srinagr
- Sirinagar
- Sirnagar

## synonym:sultanpur
- Sultanapur
- Sulatanpur
- Sultanpur

## synonym:surat
- Surat

## synonym:thiruvananthapuram
- Trivandram
- Thiruvanantapuram
- Thiruvanthapuram

## synonym:thrissur
- Thirissur
- Thrisur
- Thirisur

## synonym:tirunelveli
- Trunelveli
- Thirunelveli
- Tirnelveli

## synonym:tiruppur
- Tirupur
- Tiruppor
- Tiruppur

## synonym:ujjain
- Ujain
- Ujjan
- Ujjain

## synonym:vadodara
- Baroda
- Vadodra
- Vadodara

## synonym:varanasi
- Varansi
- Banaras
- Varanasi

## synonym:vijayawada
- Vijaywada
- Vijayawada
- Vijaiawada

## synonym:warangal
- Warangal

## regex:emailid
- [A-z0-9._%+-]+@[A-z0-9.-]+\.[A-z.]{2,4}
