## Story 1
* greet
    - utter_greet
* restaurant_search{"location": "ajmer"}
    - slot{"location": "ajmer"}
    - check_location
    - slot{"location": "ajmer"}
    - slot{"check_op": true}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - verify_cuisine
    - slot{"cuisine": "chinese"}
    - slot{"check_op": true}
    - utter_ask_price
* restaurant_search{"pricemin": "300", "pricemax": "700"}
    - slot{"pricemax": "700"}
    - slot{"pricemin": "300"}
    - check_cost
    - slot{"pricemin": 300}
    - slot{"pricemax": 700}
    - slot{"check_op": true}
    - action_search_restaurants
    - slot{"location": "ajmer"}
    - slot{"restaurant_exist": true}
    - utter_ask_email
* affirm
    - utter_ask_emailid
* send_mail{"emailid": "aman.v.shah@hotmail.com"}
    - slot{"emailid": "aman.v.shah@hotmail.com"}
    - send_email
    - utter_goodbye
	- action_restart

## Story 3
* restaurant_search{"cuisine": "italian", "location": "chennai", "pricemin": "700"}
    - slot{"cuisine": "italian"}
    - slot{"location": "chennai"}
    - slot{"pricemin": "700"}
    - check_location
    - slot{"location": "chennai"}
    - slot{"check_op": true}
    - verify_cuisine
    - slot{"cuisine": "italian"}
    - slot{"check_op": true}
    - check_cost
    - slot{"pricemin": 700}
    - slot{"pricemax": 10000}
    - slot{"check_op": true}
    - action_search_restaurants
    - slot{"location": "chennai"}
    - slot{"restaurant_exist": true}
    - utter_ask_email
* affirm
    - utter_ask_emailid
* send_mail{"emailid": "sesaravanan7@gmail.com"}
    - slot{"emailid": "sesaravanan7@gmail.com"}
    - send_email
    - utter_goodbye
	- action_restart

## Story 4
* greet
    - utter_greet
* restaurant_search{"cuisine": "mexican", "location": "pune"}
    - slot{"cuisine": "mexican"}
    - slot{"location": "pune"}
    - check_location
    - slot{"location": "pune"}
    - slot{"check_op": true}
    - verify_cuisine
    - slot{"cuisine": "mexican"}
    - slot{"check_op": true}
    - utter_ask_price
* restaurant_search{"pricemin": "300", "pricemax": "700"}
    - slot{"pricemax": "700"}
    - slot{"pricemin": "300"}
    - check_cost
    - slot{"pricemin": 300}
    - slot{"pricemax": 700}
    - slot{"check_op": true}
    - action_search_restaurants
    - slot{"location": "pune"}
    - slot{"restaurant_exist": true}
    - utter_ask_email
* affirm
    - utter_ask_emailid
* deny
    - utter_goodbye
	- action_restart

## Story 5
* restaurant_search{"location": "akola"}
    - slot{"location": "akola"}
    - check_location
    - slot{"location": "None"}
    - slot{"check_op": false}
    - utter_ask_location
* restaurant_search{"location": "akola"}
    - slot{"location": "akola"}
    - check_location
    - slot{"location": "None"}
    - slot{"check_op": false}
    - utter_goodbye
	- action_restart

## Story 6
* restaurant_search{"location": "mumbai"}
    - slot{"location": "mumbai"}
    - check_location
    - slot{"location": "mumbai"}
    - slot{"check_op": true}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "Thai"}
    - slot{"cuisine": "Thai"}
    - verify_cuisine
    - slot{"cuisine": null}
    - slot{"check_op": false}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "Greek"}
    - slot{"cuisine": "Greek"}
    - verify_cuisine
    - slot{"cuisine": null}
    - slot{"check_op": false}
    - utter_goodbye
	- action_restart

## Story 7
* restaurant_search{"location": "gurgaon"}
    - slot{"location": "gurgaon"}
    - check_location
    - slot{"location": "gurgaon"}
    - slot{"check_op": true}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "north indian"}
    - slot{"cuisine": "north indian"}
    - verify_cuisine
    - slot{"cuisine": "north indian"}
    - slot{"check_op": true}
    - utter_ask_price
* restaurant_search{"pricemin": "250", "pricemax": "550"}
    - slot{"pricemax": "550"}
    - slot{"pricemin": "250"}
    - check_cost
    - slot{"pricemin": 0}
    - slot{"pricemax": 0}
    - slot{"check_op": false}
    - utter_ask_price
* restaurant_search{"pricemin": "450", "pricemax": "800"}
    - slot{"pricemax": "800"}
    - slot{"pricemin": "450"}
    - check_cost
    - slot{"pricemin": 0}
    - slot{"pricemax": 0}
    - slot{"check_op": false}
    - utter_goodbye
	- action_restart

## Story 8
* restaurant_search{"location": "bharuch"}
    - slot{"location": "bharuch"}
    - check_location
    - slot{"location": "None"}
    - slot{"check_op": false}
    - utter_ask_location
* restaurant_search{"location": "bhavnagar"}
    - slot{"location": "bhavnagar"}
    - check_location
    - slot{"location": "bhavnagar"}
    - slot{"check_op": true}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "north indian"}
    - slot{"cuisine": "north indian"}
    - verify_cuisine
    - slot{"cuisine": "north indian"}
    - slot{"check_op": true}
    - utter_ask_price
* restaurant_search{"pricemin": "300", "pricemax": "700"}
    - slot{"pricemax": "700"}
    - slot{"pricemin": "300"}
    - check_cost
    - slot{"pricemin": 300}
    - slot{"pricemax": 700}
    - slot{"check_op": true}
    - action_search_restaurants
    - slot{"location": "bhavnagar"}
    - slot{"restaurant_exist": true}
    - utter_ask_email
* affirm
    - utter_ask_emailid
* send_mail{"emailid": "aman.v.shah"}
    - slot{"emailid": "aman.v.shah"}
    - send_email
    - utter_goodbye
	- action_restart

## Story 9
* greet
    - utter_greet
* restaurant_search{"location": "ajmer"}
    - slot{"location": "ajmer"}
    - check_location
    - slot{"location": "ajmer"}
    - slot{"check_op": true}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "south indian"}
    - slot{"cuisine": "south indian"}
    - verify_cuisine
    - slot{"cuisine": "south indian"}
    - slot{"check_op": true}
    - utter_ask_price
* restaurant_search{"pricemin": "400", "pricemax": "800"}
    - slot{"pricemax": "800"}
    - slot{"pricemin": "400"}
    - check_cost
    - slot{"pricemin": 0}
    - slot{"pricemax": 0}
    - slot{"check_op": false}
    - utter_ask_price
* restaurant_search{"pricemin": "300", "pricemax": "700"}
    - slot{"pricemax": "700"}
    - slot{"pricemin": "300"}
    - check_cost
    - slot{"pricemin": 300}
    - slot{"pricemax": 700}
    - slot{"check_op": true}
    - action_search_restaurants
    - slot{"location": "ajmer"}
    - slot{"restaurant_exist": true}
    - utter_ask_email
* affirm
    - utter_ask_emailid
* send_mail{"emailid": "sesaravanan7@gmail.com"}
    - slot{"emailid": "sesaravanan7@gmail.com"}
    - send_email
    - utter_goodbye
	- action_restart

## Story 10
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "Chennai"}
    - slot{"location": "Chennai"}
    - check_location
    - slot{"location": "Chennai"}
    - slot{"check_op": true}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "american"}
    - slot{"cuisine": "american"}
    - verify_cuisine
    - slot{"cuisine": "american"}
    - slot{"check_op": true}
    - utter_ask_price
* restaurant_search{"pricemin": "300", "pricemax": "700"}
    - slot{"pricemax": "700"}
    - slot{"pricemin": "300"}
    - check_cost
    - slot{"pricemin": 300}
    - slot{"pricemax": 700}
    - slot{"check_op": true}
    - action_search_restaurants
    - slot{"location": "Chennai"}
    - slot{"restaurant_exist": true}
    - utter_ask_email
* affirm
    - utter_ask_emailid
* send_mail{"emailid": "sesaravanan7@gmail.com"}
    - slot{"emailid": "sesaravanan7@gmail.com"}
    - send_email
    - utter_goodbye
	- action_restart